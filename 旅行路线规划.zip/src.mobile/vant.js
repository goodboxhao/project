import Vue from 'vue'

import {
  Button
} from 'vant'

Vue.use(Button)
