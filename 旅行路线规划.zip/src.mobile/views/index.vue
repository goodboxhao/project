<template>
  <div>
    <van-button type="info" block>
      Vant info button with custom color
    </van-button>
  </div>
</template>
