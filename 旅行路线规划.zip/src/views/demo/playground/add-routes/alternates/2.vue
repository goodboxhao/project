<template>
  <d2-container type="card">
    <p>src/views/demo/playground/add-routes/alternates/2.vue</p>
  </d2-container>
</template>
