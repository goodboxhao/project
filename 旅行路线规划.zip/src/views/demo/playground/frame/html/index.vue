<template>
  <d2-container-frame :src="`${$baseUrl}html/demo.html`"/>
</template>
