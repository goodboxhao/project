<template>
  <d2-container-frame src="https://d2.pub/zh/doc/d2-admin"/>
</template>
