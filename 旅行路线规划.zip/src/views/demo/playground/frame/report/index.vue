<template>
  <d2-container-frame :src="`${$baseUrl}report.html`"/>
</template>
