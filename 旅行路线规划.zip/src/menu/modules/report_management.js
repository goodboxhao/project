export default {
  path: '/management-report',
  title: '评论管理',
  icon: 'commenting',
  children: [
    { path: '/management-report/reportlist', title: '举报评论列表', icon: 'window-close' }
  ]
}
