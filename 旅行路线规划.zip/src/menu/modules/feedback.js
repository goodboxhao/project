export default {
  path: '/feedback',
  title: '用户反馈',
  icon: 'commenting',
  children: [
    { path: '/feedback/sendFeedback', title: '发送反馈', icon: 'commenting-o' }
  ]
}
