export default {
  path: '/management-user',
  title: '用户管理',
  icon: 'user',
  children: [
    { path: '/management-user/userlist', title: '用户管理', icon: 'address-book-o' },
    { path: '/management-user/userAppeal', title: '申诉处理', icon: 'info-circle' }
  ]
}
