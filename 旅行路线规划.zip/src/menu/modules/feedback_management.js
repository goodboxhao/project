export default {
  path: '/management-feedback',
  title: '反馈管理',
  icon: 'envelope-open',
  children: [
    { path: '/management-feedback/feedbacklist', title: '反馈列表', icon: 'envelope-open' }
  ]
}
