<script>
const httpUrl = 'http://192.168.1.107:8080'
export default {
  name: 'common',
  httpUrl
}
</script>
