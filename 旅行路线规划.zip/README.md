## 旅行线路规划系统前端部分
### 运行方式
1. 在项目根目录安装依赖
```npm install```

2. 根据后端实际运行IP及端口修改 ``` /src/utils/request.js```  中的 ``` baseURL```  变量

3. 运行vue项目
```npm run serve```
